const Footer = () => {
    return (
        <footer className="bg-white py-12">
            <div className="container mx-auto text-center">
                {/* Logo and Main Text */}
                <div className="mb-8">
                    <h2 className="text-3xl font-bold text-gray-900 mb-4">SelfSellPro</h2>
                    <p className="text-gray-600">
                        Hello, we are ABC. trying to make an effort to put the right people for you to get the best results.
                        <br />
                        Just insight
                    </p>
                </div>

                {/* Footer Navigation */}
                <div className="mb-8 flex justify-center space-x-6">
                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200">Features</button>
                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200">About Us</button>
                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200">Contact Us</button>
                </div>

                {/* Logo or additional icon */}
                <div className="mb-8 flex justify-center">
                    <img src="images/logo.png" alt="Footer Logo" className="w-10 h-10" />
                </div>

                {/* Copyright Section */}
                <div className="border-t border-gray-300 pt-4">
                    <p className="text-gray-500">© 2022 ABC. All Rights Reserved.</p>
                </div>

                {/* Social Media Icons */}
                <div className="mt-4 flex justify-center space-x-4">
                    <a href="#" className="bg-gray-100 p-2 rounded-full hover:bg-gray-200">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-700" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 4.6c-.9.4-1.8.7-2.8.9 1-.6 1.8-1.6 2.2-2.7-.9.6-2 1-3.1 1.3-.9-.9-2.2-1.4-3.6-1.4-2.7 0-4.8 2.2-4.8 4.9 0 .4 0 .8.1 1.2-4-.2-7.5-2.2-9.8-5.1-.4.7-.6 1.6-.6 2.5 0 1.7.9 3.2 2.2 4.1-.9 0-1.7-.3-2.4-.7 0 2.4 1.7 4.4 3.9 4.8-.4.1-.8.2-1.3.2-.3 0-.6 0-.9-.1.6 2 2.4 3.4 4.4 3.4-1.7 1.4-3.9 2.2-6.2 2.2-.4 0-.8 0-1.2-.1 2.2 1.4 4.7 2.1 7.3 2.1 8.8 0 13.6-7.4 13.6-13.7v-.6c.9-.6 1.7-1.4 2.3-2.3z" />
                        </svg>
                    </a>

                    <a href="#" className="bg-gray-100 p-2 rounded-full hover:bg-gray-200">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-700" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .79 0 1.77v20.46C0 23.21.79 24 1.77 24h20.46c.98 0 1.77-.79 1.77-1.77V1.77C24 .79 23.21 0 22.23 0zm-14.1 20.45H4.92V9.16h3.22v11.29zM6.53 7.7C5.33 7.7 4.35 6.7 4.35 5.5S5.33 3.3 6.53 3.3 8.7 4.3 8.7 5.5 7.72 7.7 6.53 7.7zm14.1 12.75h-3.22v-5.59c0-1.34-.03-3.06-1.86-3.06-1.86 0-2.14 1.45-2.14 2.95v5.7H10.4V9.16h3.09v1.54h.04c.43-.82 1.5-1.68 3.09-1.68 3.3 0 3.91 2.17 3.91 4.98v6.45z" />
                        </svg>
                    </a>

                    <a href="#" className="bg-gray-100 p-2 rounded-full hover:bg-gray-200">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-700" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M19.32 0H4.69A4.7 4.7 0 000 4.7v14.63A4.7 4.7 0 004.7 24h14.63a4.7 4.7 0 004.7-4.7V4.7A4.7 4.7 0 0019.32 0zm-8.43 18.88H7.14V9.28h3.75v9.6zm-1.87-10.88a2.18 2.18 0 01-2.17-2.17 2.18 2.18 0 112.17 2.17zm9.74 10.88h-3.75v-4.76c0-1.13-.02-2.57-1.56-2.57-1.57 0-1.81 1.23-1.81 2.5v4.83h-3.75V9.28h3.6v1.31h.05c.5-.95 1.7-1.96 3.5-1.96 3.74 0 4.43 2.46 4.43 5.67v4.58z" />
                        </svg>
                    </a>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
