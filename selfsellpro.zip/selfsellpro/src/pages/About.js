import { faUsers } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Home = () => {
    return (
        <section className="py-16 bg-gray-100">
            <div className="container mx-auto px-4 lg:px-0">
                {/* Section Header */}
                <div className="text-center mb-12">
                    <h3 className="text-orange-500 text-lg font-semibold mb-2">About Us</h3>
                    <h2 className="text-4xl font-bold text-gray-900">Who are we, what we do?</h2>
                    <p className="text-gray-600 max-w-xl mx-auto mt-4">
                        Discover how it works with simplified AI tools to sell your home. These user-friendly technologies make the process more efficient by automating tasks, providing data-driven insights.
                    </p>
                </div>

                {/* Grid of Feature Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Feature Card 1 */}
                    <div className="bg-white p-8 rounded-lg shadow-md text-center">
                        <FontAwesomeIcon icon={faUsers} className="w-12 h-12 mx-auto mb-4" />
                        <h4 className="text-xl font-semibold text-gray-900 mb-2">Lorem Ipsum is simply</h4>
                        <p className="text-gray-600">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                        </p>
                    </div>

                    {/* Feature Card 2 */}
                    <div className="bg-white p-8 rounded-lg shadow-md text-center">
                        <FontAwesomeIcon icon={faUsers} className="w-12 h-12 mx-auto mb-4" />
                        <h4 className="text-xl font-semibold text-gray-900 mb-2">Lorem Ipsum is simply</h4>
                        <p className="text-gray-600">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                        </p>
                    </div>

                    {/* Feature Card 3 */}
                    <div className="bg-white p-8 rounded-lg shadow-md text-center">
                        <FontAwesomeIcon icon={faUsers} className="w-12 h-12 mx-auto mb-4" />
                        <h4 className="text-xl font-semibold text-gray-900 mb-2">Lorem Ipsum is simply</h4>
                        <p className="text-gray-600">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                        </p>
                    </div>
                </div>

                {/* Another Row of Features Below (Optional) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
                    {/* Feature Card 4 */}
                    <div className="flex items-start">
                        <FontAwesomeIcon icon={faUsers} className="w-12 h-12 mx-auto mb-4" />
                        <p className="text-gray-600">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                        </p>
                    </div>

                    {/* Feature Card 5 */}
                    <div className="flex items-start">
                        <FontAwesomeIcon icon={faUsers} className="w-12 h-12 mx-auto mb-4" />
                        <p className="text-gray-600">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Home;
