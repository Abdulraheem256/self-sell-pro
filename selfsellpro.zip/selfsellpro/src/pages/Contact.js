// const Home = () => {
//     return (
//         <section className="py-16 bg-[#F2F7FF]">
//             <div className="container mx-auto px-4 lg:px-0">
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
//                     {/* Contact Form */}
//                     <div>
//                         <h2 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h2>
//                         <p className="text-gray-600 mb-8">
//                             Discover how it works with simplified AI tools to sell your ho These user-friendly technologies make the process more efficient by automating tasks, providing data-driven insights.
//                         </p>

//                         {/* Form */}
//                         <form className="space-y-6">
//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="name">Name *</label>
//                                 <input type="text" id="name" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your name" required />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="email">Email</label>
//                                 <input type="email" id="email" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your email" />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="phone">Phone Number *</label>
//                                 <input type="tel" id="phone" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your phone number" required />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="inquiry">How did you find us?</label>
//                                 <select id="inquiry" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
//                                     <option>Google</option>
//                                     <option>Facebook</option>
//                                     <option>Referral</option>
//                                     <option>Other</option>
//                                 </select>
//                             </div>

//                             {/* Submit Button */}
//                             <button type="submit" className="w-full bg-blue-500 text-white font-semibold py-3 rounded-lg hover:bg-blue-600">
//                                 SEND
//                             </button>
//                         </form>

//                         {/* Contact Info */}
//                         <div className="mt-8 space-y-4 text-gray-700">
//                             <div className="flex items-center space-x-4">
//                                 <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10l1.71-1.71A16.24 16.24 0 0112 4a16.24 16.24 0 017.29 4.29L21 10m-9 11a5 5 0 01-10 0c0-1.38.56-2.63 1.46-3.54A12 12 0 0112 7a12 12 0 0110.54 6.46A5 5 0 0112 21z" />
//                                 </svg>
//                                 <p>Phone: 03 5432 1234</p>
//                             </div>

//                             <div className="flex items-center space-x-4">
//                                 <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V9a4 4 0 00-8 0v2m-1 4h10m-5 7v-7" />
//                                 </svg>
//                                 <p>Fax: 123-3332-213123</p>
//                             </div>

//                             <div className="flex items-center space-x-4">
//                                 <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V9a4 4 0 00-8 0v2m-1 4h10m-5 7v-7" />
//                                 </svg>
//                                 <p>Email: info@abc.com</p>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Map */}
//                     <div className="flex items-center justify-center">
//                         <iframe
//                             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3162.912732030484!2d-122.08385148469194!3d37.42199977982512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fb5de74a6e111%3A0x808fb5de74a6e111!2sGoogleplex!5e0!3m2!1sen!2sus!4v1630416403149!5m2!1sen!2sus"
//                             width="100%"
//                             height="100%"
//                             allowFullScreen=""
//                             loading="lazy"
//                             className="rounded-lg shadow-lg"
//                         ></iframe>
//                     </div>
//                 </div>
//             </div>
//         </section>
//     );
// };

// export default Home;

// second code with icons

// const Home = () => {
//     return (
//         <section className="py-16 bg-[#F2F7FF]">
//             <div className="container mx-auto px-4 lg:px-0">
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
//                     {/* Contact Form */}
//                     <div>
//                         <h2 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h2>
//                         <p className="text-gray-600 mb-8">
//                             Discover how it works with simplified AI tools to sell your home. These user-friendly technologies make the process more efficient by automating tasks, providing data-driven insights.
//                         </p>

//                         {/* Form */}
//                         <form className="space-y-6">
//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="name">Name *</label>
//                                 <input type="text" id="name" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your name" required />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="email">Email</label>
//                                 <input type="email" id="email" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your email" />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="phone">Phone Number *</label>
//                                 <input type="tel" id="phone" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" placeholder="Enter your phone number" required />
//                             </div>

//                             <div>
//                                 <label className="block text-gray-700 mb-2" htmlFor="inquiry">How did you find us?</label>
//                                 <select id="inquiry" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
//                                     <option>Google</option>
//                                     <option>Facebook</option>
//                                     <option>Referral</option>
//                                     <option>Other</option>
//                                 </select>
//                             </div>

//                             {/* Submit Button */}
//                             <button type="submit" className="w-full bg-blue-500 text-white font-semibold py-3 rounded-lg hover:bg-blue-600">
//                                 SEND
//                             </button>
//                         </form>

//                         {/* Contact Info */}
//                         <div className="mt-8 text-gray-700">
//                             <div className="flex flex-wrap items-center justify-start lg:space-x-8 space-y-4 lg:space-y-0">
//                                 <div className="flex items-center space-x-2">
//                                 <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
// <path d="M16.2049 0.424194V2.35263C18.1123 2.35263 19.8992 2.83474 21.5657 3.79896C23.1518 4.74309 24.4167 6.00863 25.3603 7.59557C26.3241 9.26286 26.8059 11.0507 26.8059 12.959H28.7334C28.7334 10.6891 28.1612 8.57988 27.0168 6.63135C25.9125 4.74309 24.4167 3.24654 22.5294 2.14171C20.5819 0.996699 18.4737 0.424194 16.2049 0.424194ZM6.23636 3.31685C5.69426 3.31685 5.22243 3.4876 4.82088 3.82909L1.71888 6.99293L1.80923 6.93267C1.30729 7.35451 0.976004 7.8768 0.815382 8.49952C0.674839 9.12225 0.714994 9.72488 0.935848 10.3074C1.49802 11.8743 2.25094 13.4813 3.19459 15.1285C4.51971 17.3985 6.09581 19.4374 7.92288 21.2453C10.8542 24.1982 14.4983 26.5284 18.8552 28.2359H18.8853C19.4675 28.4368 20.0498 28.4769 20.6321 28.3564C21.2344 28.2359 21.7664 27.9747 22.2282 27.573L25.27 24.5297C25.6716 24.1279 25.8723 23.6357 25.8723 23.0532C25.8723 22.4506 25.6716 21.9484 25.27 21.5466L21.3247 17.5692C20.9232 17.1674 20.4212 16.9666 19.8189 16.9666C19.2166 16.9666 18.7146 17.1674 18.3131 17.5692L16.4157 19.4976C14.8898 18.7745 13.5647 17.8806 12.4404 16.8159C11.316 15.7312 10.4226 14.4154 9.75999 12.8686L11.6874 10.9402C12.1091 10.4983 12.3199 9.97598 12.3199 9.37335C12.3199 8.75062 12.079 8.24843 11.5971 7.86676L11.6874 7.95715L7.65183 3.82909C7.25028 3.4876 6.77845 3.31685 6.23636 3.31685ZM16.2049 4.28107V6.20951C17.4297 6.20951 18.554 6.51082 19.578 7.11346C20.622 7.7161 21.4452 8.5397 22.0475 9.58427C22.6499 10.6088 22.951 11.7337 22.951 12.959H24.8785C24.8785 11.3922 24.487 9.93581 23.7039 8.58992C22.9209 7.28421 21.8769 6.23964 20.5718 5.45621C19.2266 4.67278 17.771 4.28107 16.2049 4.28107ZM6.23636 5.24529C6.29659 5.24529 6.36686 5.27542 6.44717 5.33568L10.3924 9.37335C10.4125 9.4537 10.3924 9.52401 10.3322 9.58427L7.47113 12.4167L7.68195 13.0193L8.07346 13.863C8.39471 14.546 8.76614 15.2089 9.18778 15.8517C9.77003 16.7556 10.4125 17.529 11.1152 18.1718C12.0589 19.0959 13.1933 19.9396 14.5184 20.7029C15.181 21.0846 15.7431 21.3658 16.2049 21.5466L16.8073 21.8178L19.7286 18.895C19.7687 18.8548 19.7988 18.8347 19.8189 18.8347C19.839 18.8347 19.8691 18.8548 19.9093 18.895L23.975 22.9628C24.0151 23.003 24.0352 23.0331 24.0352 23.0532C24.0352 23.0532 24.0151 23.0733 23.975 23.1135L20.9633 26.0965C20.5216 26.4782 20.0398 26.5786 19.5177 26.3978C15.4219 24.8109 12.0087 22.6414 9.27812 19.8894C7.5916 18.202 6.11589 16.2836 4.851 14.1342C3.9475 12.5874 3.24478 11.0909 2.74284 9.64453V9.6144C2.66253 9.43361 2.65249 9.22269 2.71272 8.98163C2.77296 8.72049 2.88338 8.51961 3.044 8.379L6.02554 5.33568C6.08577 5.27542 6.15605 5.24529 6.23636 5.24529ZM16.2049 8.13794V10.0664C17.008 10.0664 17.6907 10.3476 18.2528 10.9101C18.815 11.4725 19.0961 12.1555 19.0961 12.959H21.0236C21.0236 12.0953 20.8027 11.2917 20.361 10.5485C19.9394 9.80524 19.3571 9.22269 18.6142 8.80084C17.8714 8.35891 17.0683 8.13794 16.2049 8.13794Z" fill="black"/>
// </svg>

//                                     <p>
//                                         Phone:<span> <br/>03 5432 1234</span>

//                                         </p>
//                                 </div>

//                                 <div className="flex items-center space-x-2">
//                                 <svg width="24" height="26" viewBox="0 0 24 26" fill="none" xmlns="http://www.w3.org/2000/svg">
// <path d="M8.0625 0.640625V5.5625H6.09375V3.59375H0.1875V21.3125H2.15625V22.2969C2.15625 23.0967 2.44336 23.7837 3.01758 24.3579C3.6123 24.9526 4.30957 25.25 5.10938 25.25C5.90918 25.25 6.59619 24.9526 7.17041 24.3579C7.76514 23.7837 8.0625 23.0967 8.0625 22.2969V21.3125H23.8125V5.5625H19.875V0.640625H8.0625ZM10.0312 2.60938H17.9062V7.53125H10.0312V2.60938ZM2.15625 5.5625H4.125V19.3438H2.15625V5.5625ZM6.09375 7.53125H8.0625V9.5H19.875V7.53125H21.8438V19.3438H6.09375V7.53125ZM9.04688 11.4688V13.4375H11.0156V11.4688H9.04688ZM12.9844 11.4688V13.4375H14.9531V11.4688H12.9844ZM16.9219 11.4688V13.4375H18.8906V11.4688H16.9219ZM9.04688 15.4062V17.375H11.0156V15.4062H9.04688ZM12.9844 15.4062V17.375H14.9531V15.4062H12.9844ZM16.9219 15.4062V17.375H18.8906V15.4062H16.9219ZM4.125 21.3125H6.09375V22.2969C6.09375 22.5635 5.99121 22.7993 5.78613 23.0044C5.60156 23.189 5.37598 23.2812 5.10938 23.2812C4.84277 23.2812 4.60693 23.189 4.40186 23.0044C4.21729 22.7993 4.125 22.5635 4.125 22.2969V21.3125Z" fill="black"/>
// </svg>

//                                     <p>
//                                     Fax:<span> <br/>123-3332-213123</span>
// </p>

//                                 </div>

//                                 <div className="flex items-center space-x-2">
//                                 <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
// <path d="M7.95455 2.625V4.59624L1.75 8.63565V25.375H26.5682V8.63565L20.3636 4.59624V2.625H7.95455ZM10.0227 4.69318H18.2955V12.6428L14.1591 15.3249L10.0227 12.6428V4.69318ZM11.0568 6.76136V8.82955H17.2614V6.76136H11.0568ZM7.95455 7.0522V11.2855L4.6907 9.18501L7.95455 7.0522ZM20.3636 7.0522L23.6275 9.18501L20.3636 11.2855V7.0522ZM11.0568 9.86364V11.9318H17.2614V9.86364H11.0568ZM3.81818 11.0916L14.1591 17.7809L24.5 11.0916V23.3068H3.81818V11.0916Z" fill="black"/>
// </svg>

//                                     <p>
//                                         Email:<span> <br/> info@abc.com </span>

//                                         </p>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Map */}
//                     <div className="flex items-center justify-center">
//                         <iframe
//                             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3162.912732030484!2d-122.08385148469194!3d37.42199977982512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fb5de74a6e111%3A0x808fb5de74a6e111!2sGoogleplex!5e0!3m2!1sen!2sus!4v1630416403149!5m2!1sen!2sus"
//                             width="100%"
//                             height="100%"
//                             allowFullScreen=""
//                             loading="lazy"
//                             className="rounded-lg shadow-lg"
//                         ></iframe>
//                     </div>
//                 </div>
//             </div>
//         </section>
//     );
// };

// export default Home;

const Home = () => {
  return (
    <section className="py-16  bg-white pb-[130px]">
      <div className="container mx-auto px-4 lg:px-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="contact-form bg-white p-6 rounded-lg ">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Contact Us
            </h2>
            <p className="text-gray-600 mb-8">
              Discover how it works with simplified AI tools to sell your home.
              These user-friendly technologies make the process more efficient
              by automating tasks, providing data-driven insights.
            </p>

            {/* Form */}
            <form className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2" htmlFor="name">
                  Name *
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="Enter your name"
                  required
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2" htmlFor="email">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2" htmlFor="phone">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="Enter your phone number"
                  required
                />
              </div>

              <div>
                            <label className="block text-gray-700 mb-2" htmlFor="inquiry">How did you find us?</label>
                                 <select id="inquiry" className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                                     <option>Google</option>
                                     <option>Facebook</option>
                                     <option>Referral</option>
                                     <option>Other</option>
                                 </select>
                             </div>

              <button
                type="submit"
                className="w-full bg-blue-500 pb-5 text-white p-3 rounded-lg"
              >
                Send Message
              </button>
            </form>
            <div className="mt-8 text-gray-700">
              <div className="flex flex-wrap items-center justify-start lg:space-x-8 space-y-4 lg:space-y-0">
                <div className="flex items-center space-x-2">
                  <svg
                    width="29"
                    height="29"
                    viewBox="0 0 29 29"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M16.2049 0.424194V2.35263C18.1123 2.35263 19.8992 2.83474 21.5657 3.79896C23.1518 4.74309 24.4167 6.00863 25.3603 7.59557C26.3241 9.26286 26.8059 11.0507 26.8059 12.959H28.7334C28.7334 10.6891 28.1612 8.57988 27.0168 6.63135C25.9125 4.74309 24.4167 3.24654 22.5294 2.14171C20.5819 0.996699 18.4737 0.424194 16.2049 0.424194ZM6.23636 3.31685C5.69426 3.31685 5.22243 3.4876 4.82088 3.82909L1.71888 6.99293L1.80923 6.93267C1.30729 7.35451 0.976004 7.8768 0.815382 8.49952C0.674839 9.12225 0.714994 9.72488 0.935848 10.3074C1.49802 11.8743 2.25094 13.4813 3.19459 15.1285C4.51971 17.3985 6.09581 19.4374 7.92288 21.2453C10.8542 24.1982 14.4983 26.5284 18.8552 28.2359H18.8853C19.4675 28.4368 20.0498 28.4769 20.6321 28.3564C21.2344 28.2359 21.7664 27.9747 22.2282 27.573L25.27 24.5297C25.6716 24.1279 25.8723 23.6357 25.8723 23.0532C25.8723 22.4506 25.6716 21.9484 25.27 21.5466L21.3247 17.5692C20.9232 17.1674 20.4212 16.9666 19.8189 16.9666C19.2166 16.9666 18.7146 17.1674 18.3131 17.5692L16.4157 19.4976C14.8898 18.7745 13.5647 17.8806 12.4404 16.8159C11.316 15.7312 10.4226 14.4154 9.75999 12.8686L11.6874 10.9402C12.1091 10.4983 12.3199 9.97598 12.3199 9.37335C12.3199 8.75062 12.079 8.24843 11.5971 7.86676L11.6874 7.95715L7.65183 3.82909C7.25028 3.4876 6.77845 3.31685 6.23636 3.31685ZM16.2049 4.28107V6.20951C17.4297 6.20951 18.554 6.51082 19.578 7.11346C20.622 7.7161 21.4452 8.5397 22.0475 9.58427C22.6499 10.6088 22.951 11.7337 22.951 12.959H24.8785C24.8785 11.3922 24.487 9.93581 23.7039 8.58992C22.9209 7.28421 21.8769 6.23964 20.5718 5.45621C19.2266 4.67278 17.771 4.28107 16.2049 4.28107ZM6.23636 5.24529C6.29659 5.24529 6.36686 5.27542 6.44717 5.33568L10.3924 9.37335C10.4125 9.4537 10.3924 9.52401 10.3322 9.58427L7.47113 12.4167L7.68195 13.0193L8.07346 13.863C8.39471 14.546 8.76614 15.2089 9.18778 15.8517C9.77003 16.7556 10.4125 17.529 11.1152 18.1718C12.0589 19.0959 13.1933 19.9396 14.5184 20.7029C15.181 21.0846 15.7431 21.3658 16.2049 21.5466L16.8073 21.8178L19.7286 18.895C19.7687 18.8548 19.7988 18.8347 19.8189 18.8347C19.839 18.8347 19.8691 18.8548 19.9093 18.895L23.975 22.9628C24.0151 23.003 24.0352 23.0331 24.0352 23.0532C24.0352 23.0532 24.0151 23.0733 23.975 23.1135L20.9633 26.0965C20.5216 26.4782 20.0398 26.5786 19.5177 26.3978C15.4219 24.8109 12.0087 22.6414 9.27812 19.8894C7.5916 18.202 6.11589 16.2836 4.851 14.1342C3.9475 12.5874 3.24478 11.0909 2.74284 9.64453V9.6144C2.66253 9.43361 2.65249 9.22269 2.71272 8.98163C2.77296 8.72049 2.88338 8.51961 3.044 8.379L6.02554 5.33568C6.08577 5.27542 6.15605 5.24529 6.23636 5.24529ZM16.2049 8.13794V10.0664C17.008 10.0664 17.6907 10.3476 18.2528 10.9101C18.815 11.4725 19.0961 12.1555 19.0961 12.959H21.0236C21.0236 12.0953 20.8027 11.2917 20.361 10.5485C19.9394 9.80524 19.3571 9.22269 18.6142 8.80084C17.8714 8.35891 17.0683 8.13794 16.2049 8.13794Z"
                      fill="black"
                    />
                  </svg>

                  <p>
                    Phone:
                    <span>
                      {" "}
                      <br />
                      03 5432 1234
                    </span>
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <svg
                    width="24"
                    height="26"
                    viewBox="0 0 24 26"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M8.0625 0.640625V5.5625H6.09375V3.59375H0.1875V21.3125H2.15625V22.2969C2.15625 23.0967 2.44336 23.7837 3.01758 24.3579C3.6123 24.9526 4.30957 25.25 5.10938 25.25C5.90918 25.25 6.59619 24.9526 7.17041 24.3579C7.76514 23.7837 8.0625 23.0967 8.0625 22.2969V21.3125H23.8125V5.5625H19.875V0.640625H8.0625ZM10.0312 2.60938H17.9062V7.53125H10.0312V2.60938ZM2.15625 5.5625H4.125V19.3438H2.15625V5.5625ZM6.09375 7.53125H8.0625V9.5H19.875V7.53125H21.8438V19.3438H6.09375V7.53125ZM9.04688 11.4688V13.4375H11.0156V11.4688H9.04688ZM12.9844 11.4688V13.4375H14.9531V11.4688H12.9844ZM16.9219 11.4688V13.4375H18.8906V11.4688H16.9219ZM9.04688 15.4062V17.375H11.0156V15.4062H9.04688ZM12.9844 15.4062V17.375H14.9531V15.4062H12.9844ZM16.9219 15.4062V17.375H18.8906V15.4062H16.9219ZM4.125 21.3125H6.09375V22.2969C6.09375 22.5635 5.99121 22.7993 5.78613 23.0044C5.60156 23.189 5.37598 23.2812 5.10938 23.2812C4.84277 23.2812 4.60693 23.189 4.40186 23.0044C4.21729 22.7993 4.125 22.5635 4.125 22.2969V21.3125Z"
                      fill="black"
                    />
                  </svg>

                  <p>
                    Fax:
                    <span>
                      {" "}
                      <br />
                      123-3332-213123
                    </span>
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <svg
                    width="28"
                    height="28"
                    viewBox="0 0 28 28"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7.95455 2.625V4.59624L1.75 8.63565V25.375H26.5682V8.63565L20.3636 4.59624V2.625H7.95455ZM10.0227 4.69318H18.2955V12.6428L14.1591 15.3249L10.0227 12.6428V4.69318ZM11.0568 6.76136V8.82955H17.2614V6.76136H11.0568ZM7.95455 7.0522V11.2855L4.6907 9.18501L7.95455 7.0522ZM20.3636 7.0522L23.6275 9.18501L20.3636 11.2855V7.0522ZM11.0568 9.86364V11.9318H17.2614V9.86364H11.0568ZM3.81818 11.0916L14.1591 17.7809L24.5 11.0916V23.3068H3.81818V11.0916Z"
                      fill="black"
                    />
                  </svg>
                  <p>
                    Email:
                    <span>
                      {" "}
                      <br /> info@abc.com{" "}
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          {/* Google Map */}
          <div className=" w-[730px]  mt-[-70px]   google-map bg-[#F2F7FF] pl-0 p-6 pt-20 pb-20 ">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.019112484634!2d144.9630579153169!3d-37.81410797975171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf577d1b6e1b0b1b!2sFederation%20Square!5e0!3m2!1sen!2sau!4v1611812392000!5m2!1sen!2sau"
              width="545px"
              height="800px"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Home;
