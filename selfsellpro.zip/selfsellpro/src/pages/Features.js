import { faUsers } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Home = () => {
    return (
        <section className="py-16 bg-gray-100">
            <div className="container mx-auto px-4 lg:px-0">
                {/* Section Header */}
                <div className="text-center mb-16">
                    <h3 className="font-rubik font-normal text-[20px] text-orange-500 text-lg font-semibold mb-2">Features</h3>
                    <h2 className="font-rubik text-[40px] font-normal  text-[#23214B]">List of Features</h2>
                    <p className="text-[#222222] font-rubik font-normal text-base max-w-xl mx-auto mt-4">
                        Discover how it works with simplified AI tools to sell your home. These user-friendly technologies
                        make the process more efficient by automating tasks, providing data-driven insights.
                    </p>
                </div>

                {/* Main Content */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    {/* Left Side: Text and Icons */}
                    <div>
                        <h3 className="font-roboto font-medium text-[36px]  text-[#091133] mb-6">Light, Fast & Powerful</h3>
                        <p className="font-roboto text-base font-normal text-[#6F7CB2] mb-8">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
                            Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,
                            ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                        </p>

                        {/* Features Icons */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            {/* Feature 1 */}
                            <div className="flex items-start">
                                <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="font-roboto text-base font-medium text-[#091133] mb-1">Title Goes Here</h4>
                                    <p className="font-roboto font-normal text-sm text-[#5D6970]">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.</p>
                                </div>
                            </div>

                            {/* Feature 2 */}
                            <div className="flex items-start">
                                <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                               <div>
                                    <h4 className="font-roboto text-base font-medium text-[#091133] mb-1">Title Goes Here</h4>
                                    <p className="font-roboto font-normal text-sm text-[#5D6970]">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.</p>
                                </div>
                            </div>

                           
                        </div>
                    </div>

                    {/* Right Side: Illustration/Image */}
                    <div className="flex justify-center lg:justify-end">
                        <img src="images/undraw_mobile_login_ikmv.png" alt="Illustration" className="w-full max-w-sm max-h-sm" />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Home;
