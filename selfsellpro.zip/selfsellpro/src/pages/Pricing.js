const Home = () => {
    return (
        <section className="py-16 bg-gray-100">
            <div className="container mx-auto px-4 lg:px-0">
                {/* Section Header */}
                <div className="text-center mb-12">
                    <h3 className="text-orange-500 text-lg font-semibold mb-2">Pricing</h3>
                    <h2 className="text-4xl font-bold text-gray-900">Pricing Based on your needs</h2>
                    <p className="text-gray-600 max-w-xl mx-auto mt-4">
                        Discover how it works with simplified AI tools to sell your home. These user-friendly technologies make the process more efficient by automating tasks, providing data-driven insights.
                    </p>
                </div>

                {/* Pricing Cards */}
                <div className="space-y-8">
                    {/* Pricing Card 1 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg flex justify-between items-center">
                        <div>
                            <h3 className="text-2xl font-semibold text-gray-900 mb-2">AI-Essentials (Basic)</h3>
                            <p className="text-gray-600">AI Pricing, Basic Listing, Email Support</p>
                        </div>
                        <div className="text-right">
                            <h4 className="text-4xl font-bold text-gray-900 mb-4">$299</h4>
                            <button className="px-6 py-3 bg-blue-500 text-white rounded-full hover:bg-blue-600">
                                Purchase Now
                            </button>
                        </div>
                    </div>

                    {/* Pricing Card 2 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg flex justify-between items-center">
                        <div>
                            <h3 className="text-2xl font-semibold text-gray-900 mb-2">AI-PRO (Pro)</h3>
                            <p className="text-gray-600">
                                Everything in Essentials + Virtual Staging, Enhanced Visibility, Phone Support
                            </p>
                        </div>
                        <div className="text-right">
                            <h4 className="text-4xl font-bold text-gray-900 mb-4">$599</h4>
                            <button className="px-6 py-3 bg-blue-500 text-white rounded-full hover:bg-blue-600">
                                Purchase Now
                            </button>
                        </div>
                    </div>

                    {/* Pricing Card 3 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg flex justify-between items-center">
                        <div>
                            <h3 className="text-2xl font-semibold text-gray-900 mb-2">AI-Elite (Premium)</h3>
                            <p className="text-gray-600">
                                Everything in Pro + Predictive Market Analysis, Priority Listing, Dedicated Agent
                            </p>
                        </div>
                        <div className="text-right">
                            <h4 className="text-4xl font-bold text-gray-900 mb-4">$999</h4>
                            <button className="px-6 py-3 bg-blue-500 text-white rounded-full hover:bg-blue-600">
                                Purchase Now
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Home;
