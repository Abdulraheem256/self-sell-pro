const PropertyDetails = () => {
    return (
        <section className="py-16 bg-gray-100">
            <div className="container mx-auto px-4 lg:px-0">
                {/* Section Header */}
                <div className="text-center mb-12">
                    <h2 className="text-4xl font-bold text-gray-900">Property Details</h2>
                    <p className="text-gray-600 mt-4">Please provide the following information</p>
                </div>

                {/* Property Address Form */}
                <div className="mb-12">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">What’s your property address?</h3>
                    <p className="text-gray-600 mb-6">
                        If you do not know or have an exact street address, e.g., for land, please provide your PARCEL ID or TAX ID in the Street Address field.
                    </p>

                    {/* Form Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <input type="text" placeholder="Address Line 1 *" className="p-4 border border-gray-300 rounded-lg w-full" />
                        <input type="text" placeholder="Address Line 2" className="p-4 border border-gray-300 rounded-lg w-full" />
                        <input type="text" placeholder="City" className="p-4 border border-gray-300 rounded-lg w-full" />
                        <input type="text" placeholder="State" className="p-4 border border-gray-300 rounded-lg w-full" />
                        <input type="text" placeholder="Zip/Postal" className="p-4 border border-gray-300 rounded-lg w-full" />
                        <input type="text" placeholder="Country" className="p-4 border border-gray-300 rounded-lg w-full" />
                    </div>
                </div>

                {/* Property Type Section */}
                <div className="mb-12">
                    <h3 className="text-2xl font-bold text-gray-900 mb-6">What’s your property type?</h3>

                    {/* Property Type Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {/* Property Type Card 1 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Property Type Card 2 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Property Type Card 3 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Property Type Card 4 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Property Type Card 5 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Property Type Card 6 */}
                        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                            <div className="flex items-start">
                                <img src="path-to-icon.svg" alt="Property Icon" className="w-10 h-10 mr-4" />
                                <div>
                                    <h4 className="text-xl font-bold text-gray-900 mb-2">Title Goes Here</h4>
                                    <p className="text-gray-600">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default PropertyDetails;
