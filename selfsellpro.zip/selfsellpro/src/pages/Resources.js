import { faUsers } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Home = () => {
    return (
        <section className="py-16 bg-gray-100">
            <div className="container mx-auto px-4 lg:px-0">
                {/* Section Header */}
                <div className="text-center mb-12">
                    <h2 className="font-rubik text-[40px] font-normal text-[#23214B]">Resources</h2>
                    <p className="font-rubik text-base font-normal text-[#222222] mt-4">Please provide the following information</p>
                </div>

                {/* Resources Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Resource Card 1 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Resource Card 2 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Resource Card 3 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Resource Card 4 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Resource Card 5 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Resource Card 6 */}
                    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200">
                        <div className="flex items-start">
                            <FontAwesomeIcon icon={faUsers} className="w-10 h-10 mr-4" />
                            <div>
                                <h4 className="text-xl font-bold text-gray-900">Title Goes Here</h4>
                                <p className="text-gray-600">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Home;
